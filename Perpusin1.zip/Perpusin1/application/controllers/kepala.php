<?php
defined('BASEPATH') or exit('No direct script access allowed');

class kepala extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('status') != "login") {
            redirect(base_url() . 'welcome?pesan=belumlogin');
        }
    }

    function index()
    {
        $data['transaksi'] = $this->db->query("select * from peminjaman order by id_pinjam desc limit 10")->result();
        $data['kepala'] = $this->db->query("select * from kepala order by id_kepala desc limit 10")->result();

        $transaksi = $data['transaksi'];

        $this->load->view('kepala/header');
        $this->load->view('kepala/index', $data);
        $this->load->view('kepala/footer');
    }

    function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url() . 'welcome?pesan=logout');
    }

    function cetak_laporan_buku()
    {
        $data['buku'] = $this->M_perpus->get_data('buku')->result();
        $this->load->view('kepala/header');
        $this->load->view('kepala/laporan_buku', $data);
        $this->load->view('kepala/footer');
    }

    function laporan_print_buku()
    {
        $data['buku'] = $this->M_perpus->get_data('buku')->result();
        $this->load->view('kepala/laporan_print_buku', $data);
    }

    function laporan_pdf_buku()
    {
        $this->load->library('dompdf_gen');

        $data['buku'] = $this->M_perpus->get_data('buku')->result();

        $this->load->view('kepala/laporan_pdf_buku', $data);

        $paper_size  = 'A4'; // ukuran kertas
        $orientation = 'landscape'; //tipe format kertas potrait atau landscape
        $html = $this->output->get_output();

        $this->dompdf->set_paper($paper_size, $orientation);
        //Convert to PDF
        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("laporan_data_buku.pdf", array('Attachment' => 0));
        // nama file pdf yang di hasilkan
    }

    function cetak_laporan_anggota()
    {
        $data['anggota'] = $this->M_perpus->get_data('anggota')->result();
        $this->load->view('kepala/header');
        $this->load->view('kepala/laporan_anggota', $data);
        $this->load->view('kepala/footer');
    }

    function laporan_print_anggota()
    {
        $data['anggota'] = $this->M_perpus->get_data('anggota')->result();
        $this->load->view('kepala/laporan_print_anggota', $data);
    }

    function laporan_pdf_anggota()
    {
        $this->load->library('dompdf_gen');

        $data['anggota'] = $this->M_perpus->get_data('anggota')->result();

        $this->load->view('kepala/laporan_pdf_anggota', $data);

        $paper_size  = 'A4'; // ukuran kertas
        $orientation = 'landscape'; //tipe format kertas potrait atau landscape
        $html = $this->output->get_output();

        $this->dompdf->set_paper($paper_size, $orientation);
        //Convert to PDF
        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("laporan_data_anggota.pdf", array('Attachment' => 0));
        // nama file pdf yang di hasilkan
    }

    function laporan_transaksi()
    {
        $dari = $this->input->post('dari');
        $sampai = $this->input->post('sampai');
        $this->form_validation->set_rules('dari', 'Dari Tanggal', 'required');
        $this->form_validation->set_rules('sampai', 'Sampai Tanggal', 'required');

        if ($this->form_validation->run() != false) {

            $data['laporan'] = $this->db->query("select * from peminjaman p,detail_pinjam d,
          buku b,anggota a where d.id_buku=b.id_buku and p.id_anggota=a.id_anggota
          and p.id_pinjam=d.id_pinjam and date(tanggal_input) >= '$dari'")->result();

            $this->load->view('kepala/header');
            $this->load->view('kepala/laporan_filter_transaksi', $data);
            $this->load->view('kepala/footer');
        } else {
            $this->load->view('kepala/header');
            $this->load->view('kepala/laporan_transaksi');
            $this->load->view('kepala/footer');
        }
    }

    function laporan_print_transaksi()
    {
        $dari = $this->input->get('dari');
        $sampai = $this->input->get('sampai');

        if ($dari != "" && $sampai != "") {
            $data['laporan'] = $this->db->query("select * from peminjaman p,detail_pinjam d,buku b,anggota a where d.id_buku=b.id_buku and p.id_anggota=a.id_anggota and p.id_pinjam=d.id_pinjam and date(tanggal_input) >= '$dari'")->result();
            $this->load->view('kepala/laporan_print_transaksi', $data);
        } else {
            redirect("kepala/laporan_transaksi");
        }
    }

    function laporan_pdf_transaksi()
    {
        $this->load->library('dompdf_gen');
        $dari = $this->input->get('dari');
        $sampai = $this->input->get('sampai');

        $data['laporan'] = $this->db->query("select * from peminjaman p,detail_pinjam d,buku b,anggota a
          where d.id_buku=b.id_buku and p.id_anggota=a.id_anggota and p.id_pinjam=d.id_pinjam and date(tanggal_input)
          >= '$dari'")->result();

        $this->load->view('kepala/laporan_pdf_transaksi', $data);

        $paper_size  = 'A4'; // ukuran kertas
        $orientation = 'landscape'; //tipe format kertas potrait atau landscape
        $html = $this->output->get_output();

        $this->dompdf->set_paper($paper_size, $orientation);
        //Convert to PDF
        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("laporan_data_transaksi.pdf", array('Attachment' => 0));
    }
}
