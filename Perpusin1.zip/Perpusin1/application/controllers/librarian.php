<?php
defined('BASEPATH') or exit('No direct script access allowed');

class librarian extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('status') != "login") {
            redirect(base_url() . 'welcome?pesan=belumlogin');
        }
    }

    function index()
    {
        $data['transaksi'] = $this->db->query("select * from peminjaman order by id_pinjam desc limit 10")->result();
        $data['librarian'] = $this->db->query("select * from librarian order by id_librarian desc limit 10")->result();

        $transaksi = $data['transaksi'];

        $this->load->view('librarian/header');
        $this->load->view('librarian/index', $data);
        $this->load->view('librarian/footer');
    }

    function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url() . 'welcome?pesan=logout');
    }

    function librarian()
    {
        $data['librarian'] = $this->M_perpus->get_data('buku')->result();
        $this->load->view('librarian/header');
        $this->load->view('librarian/buku', $data);
        $this->load->view('librarian/footer');
    }

    function tambah_buku()
    {
        $data['kategori'] = $this->M_perpus->get_data('kategori')->result();
        $this->load->view('librarian/header');
        $this->load->view('librarian/tambahbuku', $data);
        $this->load->view('librarian/footer');
    }

    function tambah_buku_act()
    {
        $tgl_input = date('Y-m-d');
        $id_kategori = $this->input->post('id_kategori');
        $judul = $this->input->post('judul_buku');
        $pengarang = $this->input->post('pengarang');
        $penerbit = $this->input->post('penerbit');
        $thn_terbit = $this->input->post('thn_terbit');
        $isbn = $this->input->post('isbn');
        $jumlah_buku = $this->input->post('jumlah_buku');
        $lokasi = $this->input->post('lokasi');
        $status = $this->input->post('status');
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('judul_buku', 'Judul Buku', 'required');
        $this->form_validation->set_rules('status', 'Status Buku', 'required');
        if ($this->form_validation->run() != false) {
            //configurasi upload Gambar
            $config['upload_path'] = './assets/upload/';
            $config['allowed_types'] = 'jpg|png|jpeg';
            $config['max_size'] = '2048';
            $config['file_name'] = 'gambar' . time();

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $image = $this->upload->data();

                $data = array(
                    'id_kategori' => $id_kategori,
                    'judul_buku' => $judul,
                    'pengarang' => $pengarang,
                    'penerbit' => $penerbit,
                    'thn_terbit' => $thn_terbit,
                    'isbn' => $isbn,
                    'jumlah_buku' => $jumlah_buku,
                    'lokasi' => $lokasi,
                    'gambar' => $image['file_name'],
                    'tgl_input' => $tgl_input,
                    'status_buku' => $status
                );
                $this->M_perpus->insert_data($data, 'buku');
                redirect(base_url() . 'librarian/buku');
            } else {
                $this->load->view('librarian/header');
                $this->load->view('librarian/tambahbuku');
                $this->load->view('librarian/footer');
            }
        }
    }

    function hapus_buku($id)
    {
        $where = array('id_buku' => $id);
        $this->M_perpus->delete_data($where, 'buku');
        redirect(base_url() . 'librarian/buku');
    }

    function edit_buku($id)
    {
        $where = array('id_buku' => $id);
        $data['buku'] = $this->db->query("select * from buku B, kategori K where B.id_kategori=K.id_kategori and B.id_buku='$id'")->result();
        $data['kategori'] = $this->M_perpus->get_data('kategori')->result();

        $this->load->view('librarian/header');
        $this->load->view('librarian/editbuku', $data);
        $this->load->view('librarian/footer');
    }
}
