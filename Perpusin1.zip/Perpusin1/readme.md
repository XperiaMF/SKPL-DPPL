# Aplikasi Perpustakaan WEB 3
Iseng-iseng benerin aplikasi Perpustakaan yang ada di Modul Pemrograman Web 3, karena dibutuhkan pada pembelajaran E-Learning semester 5 untuk dikembangkan Resp APInya.

## Tentang Saya 
<p  align="center">
  <img width="200px" height="200px" src="https://1.bp.blogspot.com/-JYoVTVvNti8/XD14Y5j6spI/AAAAAAAAC5Q/UOZ0mnILQost96u_VMwnWc61wz60k3zJQCPcBGAYYCw/s500-cc/Nizwar-ID-Header-Background.JPG"/>  
  <br/>
<label>  Hanya manusia biasa yang suka makan coklat</label>
  </p>
  
  > Tinggalkan notice sebelum mendistribusikan ulang kode sumber ini gaes...
  > silahkan email ke [Nizwar@merahputih.id](mailto:nizwar@merahputih.id) 😄😁

