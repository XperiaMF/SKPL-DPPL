<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    if ($this->session->userdata('status') != "login") {
      redirect(base_url() . 'welcome?pesan=belumlogin');
    }
  }

  function index()
  {
    $transaksi = $data['transaksi'];

    $this->load->view('admin/header');
    $this->load->view('admin/index', $data);
    $this->load->view('admin/footer');
  }

  function logout()
  {
    $this->session->sess_destroy();
    redirect(base_url() . 'welcome?pesan=logout');
  }
}
